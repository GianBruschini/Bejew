package com.example.prueba;

import android.media.Image;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.GridLayout;
import android.widget.ImageView;

import java.util.Random;


public class MainActivity extends AppCompatActivity {
    private int[] vector = new int[]{R.drawable.blue, R.drawable.green, R.drawable.yellow, R.drawable.red, R.drawable.purple, R.drawable.orange};
    int matriz[][] = new int[8][8];
    int auxMatriz;
    int cantClicks = 0;
    int dondeEstoy;
    int dondeEstoy2;
    int auxMatriz2;
    int EnX;
    int EnY;
    int click1;
    int click2;
    int ub;
    int Clicks;
    int elnumero;



    GridLayout grilla;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        grilla = findViewById(R.id.grid);
        elnumero = 6;
        for (int x = 0; x < matriz.length; x++) {
            for (int y = 0; y < matriz[x].length; y++) {
                int random = (int) (Math.random() * elnumero);
                ub = x * 8 + y;
                ImageView prueba = (ImageView) grilla.getChildAt(ub);// .setVisibility(View.INVISIBLE);
                prueba.setImageResource(vector[random]);
                matriz[x][y] = random+1;
            }

        }

        barrido();
        imagenes();
        instanciarSetOnClick();

    }


    //------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
    public boolean barrido() {

        boolean huboJuego= false;
        for ( int fila = 0; fila < 8; fila++){
            for( int columna = 0; columna < 6 ; columna ++){
                if(matriz[fila][columna] > 0) {
                    if(Math.abs(matriz[fila][columna])  ==
                            Math.abs(matriz[fila][columna +1]) &&
                            (Math.abs(matriz[fila][columna]) ==
                                    (Math.abs(matriz[fila][columna+2])))) {   // HABIA ENCONTRADO OTRA FORMA PARA HACERLO QUE ERA PONER IF(NUMERO < 0){ numero = numero * -1; pero tendria problemas

                        ;// ACA IRIA PREGUNTANDO DE A 3 SI HAY JUEGO, TENGO QUE PONER MATH ABS POR SI ESA POSICION YA ESTABA EN NEGATIVO, ESTO ME SOLUCIONARIA EL PROBLEMA DE FORMAR LA "T"
                        huboJuego = true;
                        if (matriz[fila][columna] > 0 ){   // a cada elemento que encuentro lo multiplico por -1 asi cuando el proceso "imagenes" detecte que hay un valor negativo, lo pueda borrar
                            matriz[fila][columna]= matriz[fila][columna] * -1;

                        }
                        if (matriz[fila][columna + 1] > 0 ){
                            matriz[fila][columna + 1]=  matriz[fila][columna + 1] *-1;

                        }
                        if (matriz[fila][columna + 2] > 0 ){
                            matriz[fila][columna + 2]= matriz[fila][columna + 2]*-1;

                        }
                    }

                }
            }
        }

        for ( int fila = 0; fila < 6; fila++){
            for( int columna = 0; columna < 8 ; columna ++){
                if(matriz[fila][columna] > 0) {
                    if(Math.abs(matriz[fila][columna])  ==
                            Math.abs(matriz[fila+1][columna ]) &&
                            (Math.abs(matriz[fila][columna]) == (Math.abs(matriz[fila+2][columna])))) {
                        System.out.println("Entre 2");// ACA IRIA PREGUNTANDO DE A 3 SI HAY JUEGO, TENGO QUE PONER MATH ABS POR SI ESA POSICION YA ESTABA EN NEGATIVO, ESTO ME SOLUCIONARIA EL PROBLEMA DE FORMAR LA "T"
                        huboJuego = true;
                        if (matriz[fila][columna] > 0 ){    // a cada elemento que encuentro lo multiplico por -1 asi cuando el metodo "imagenes" detecte que hay un valor negativo, lo pueda borrar
                            matriz[fila][columna]= matriz[fila][columna] * -1;

                        }
                        if (matriz[fila+1][columna ] > 0 ){
                            matriz[fila+1][columna]=  matriz[fila+1][columna]*-1;

                        }
                        if (matriz[fila+2][columna] > 0 ){
                            matriz[fila+2][columna ]= matriz[fila+2][columna ]*-1;

                        }
                    }

                }
            }
        }
        return huboJuego;


    }


    //----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

    public void imagenes(){
        int ubicaion;
        ImageView imagen;
        for ( int fila = 0; fila < 8; fila++) {
            for (int columna = 0; columna < 8; columna++) {
                ubicaion = fila * 8 + columna;
                imagen = (ImageView) grilla.getChildAt(ubicaion);
                if (matriz[fila][columna] < 0) {      // A CADA POSICION QUE TENGA UN VALOR NEGATIVO O SEA MENOR QUE 0 ,LA HAGO DESAPARECER
                    imagen.setVisibility(View.INVISIBLE);
                } else {

                    imagen.setImageResource(vector[matriz[fila][columna] - 1]);
                }
            }
        }
    }


   /* public void cruzada() {

        GridLayout grid = (GridLayout) findViewById(R.id.grid);
        int aux;
        for (int fila = 0; fila < 8; fila++) {
            cant = 0;
            aux = Math.abs(matriz[fila][0]);
            for (int columna = 0; columna < 8; columna++) {

                if (Math.abs(matriz[fila][columna]) == aux) {
                    cant = cant + 1;
                    auxCant = cant;
                    if( cant == 1 ){
                        posX = x;
                        posY = y;
                    }


                }

                if ((auxCant >= 3) && (aux != Math.abs(matriz[fila][columna]))) {
                    for (int i = 1; i <= auxCant; i++) {
                        matriz[posX][posY] = -1;
                        posY++;
                    }
                }

                if ( aux != Math.abs(matriz[fila][columna])){
                    aux = Math.abs(matriz[fila][columna]);
                    cant = 1;
                    posX = fila;
                    posY = columna;


                }


            }
        }


    }
    */

   /* public void imagen(){
        GridLayout grid = (GridLayout) findViewById(R.id.grid);
        for (int fila = 0; fila < 8; fila++) {
            for (int columna = 0; columna < 8; columna++) {
                if(matriz[fila][columna] < 0){

                    ImageView prueba = (ImageView) grid.getChildAt(fila*8+columna);
                    prueba.setVisibility(View.INVISIBLE);
                }

            }


        }

    }


   */


    //-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
    public void instanciarSetOnClick() {


        for (int x = 0; x < matriz.length; x++) {
            for (int y = 0; y < matriz[x].length; y++) {
                int ubicacion = x * 8 + y;

                final int posX = x;
                final int posY = y;

                grilla.getChildAt(ubicacion).setOnClickListener(new View.OnClickListener() {  //a cada imagen seteada en la matriz le asigno un onClickListener, es decir que cuando se haga click va a responder a cierto "evento/logica"
                    @Override
                    public void onClick(View v) {
                        MainActivity.this.onGemaClick(posX, posY);

                    }
                });

            }
        }
    }

    //--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

    public void onGemaClick(int x, int y) {
        ImageView ActImagen;
        ImageView ActImagen2;
        int auxPos;
        int auxPos2;





        Clicks = Clicks + 1;


        if (Clicks == 1) {
            click1 = 1;     // ASIGNO PARA LUEGO COMPARAR
            auxMatriz = matriz[x][y]; // ME GUARDO EL VALOR DE LA POS (X,Y) EN MI MATRIZ DEL PRIMER CLICK
            dondeEstoy = x * 8 + y; // ME GUARDO LA UBICACION DE DONDE HICE EL PRIMER CLICK
            EnX = x;   // ME GUARDO EN UNA VARIABLE MI X
            EnY = y;   // ME GUARDO EN OTRA VARIABLE MY Y


        }
        if (Clicks == 2) {
            click2 = 2;   // ASIGNO PARA LUEGO COMPARAR
            auxMatriz2 = matriz[x][y]; // ME GUARDO EL VALOR DE LA POS (X,Y) DE MI MATRIZ DEL PRIMER CLICK
            dondeEstoy2 = x * 8 + y; // ME GUARDO LA UBICACION PARA SABER EN DONDE HICE EL CLICK
            auxPos = matriz[x][y];
            matriz[x][y] = matriz[EnX][EnY];  // HAGO EL INTERCAMBIO EN LA MATRIZ
            matriz[EnX][EnY] = auxPos; // HAGO EL INTERCAMBIO  EN LA MATRIZ
            if (click1 != click2) {   //HAGO LA COMPARACION PARA SABER SI NO SE HIZO UN TERCER CLICK


                Boolean hubojuego = barrido();
                System.out.println(hubojuego);


                if(!hubojuego){
                    System.out.println("hola");
                /*    ActImagen = (ImageView) grilla.getChildAt(dondeEstoy2);
                    ActImagen.setImageResource(vector[auxMatriz2-1]);
                    ActImagen2 = (ImageView) grilla.getChildAt(dondeEstoy);
                    ActImagen2.setImageResource(vector[auxMatriz-1]);*/

                    auxPos = matriz[x][y];
                    matriz[x][y] = matriz[EnX][EnY];  // HAGO EL INTERCAMBIO EN LA MATRIZ
                    matriz[EnX][EnY] = auxPos; // HAGO EL INTERCAMBIO  EN LA MATRIZ
                }
                imagenes();







            }


        }
        if(Clicks == 2){
            Clicks = 0;
        }




    }





}

// FIN xd


